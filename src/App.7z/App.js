import "./App.css";
import myjson from "./refs.json";
import PickColor from "./PickColor";

function App() {
  const images = myjson.images;

  return (
    <div>
      <PickColor />
      <div className="gallery">
        {images.map((index, i) => {
          return <img src={`./images/${index.name}`} key={i} alt="" />;
          <div className="colorBox">palette</div>
        })}
      </div>
    </div>
  );
}

export default App;
